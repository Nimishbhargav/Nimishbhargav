
<img src="https://raw.githubusercontent.com/Nimishbhargav/Nimishbhargav-/main/banner.png.png" width="100%">
<h1 align="center">
  <img src="https://readme-typing-svg.herokuapp.com?font=Fira+Code&size=30&pause=1000&center=true&vCenter=true&width=1000&height=60&lines=Hey!+I'm+%40NimishCodes;Software+Engineer+Student;Full+Stack+Developer;Coding+💻+%7C+Music+🎧+%7C+Romantic+💙" alt="Typing SVG" />
</h1>
...
<!-- 💖 If you're reading this... you're already special to me 💖 -->
